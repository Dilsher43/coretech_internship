const toggleBtn = document.getElementById('mode-toggle');
toggleBtn?.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  toggleBtn.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
});

const scrollTopBtn = document.getElementById('scrollTopBtn');
window.addEventListener('scroll', () => {
  if (window.scrollY > 300) scrollTopBtn.style.display = 'block';
  else scrollTopBtn.style.display = 'none';
});
scrollTopBtn?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const form = document.getElementById('contactForm');
form?.addEventListener('submit', e => {
  e.preventDefault();
  alert('Thanks for contacting me, your message has been sent!');
  form.reset();
});