Coretech Innovations - Final Frontend Task
Files:
- index.html
- about.html
- services.html
- portfolio.html
- contact.html
- style.css
- script.js
- assets/ (svg placeholders)

How to use:
Open index.html in a browser. All pages are static and linked together.

Notes:
- This is an original implementation inspired by coretechintl.com visuals and layout.
- Modal, form validation, sticky nav, smooth scroll, and dark/light toggle are implemented.
