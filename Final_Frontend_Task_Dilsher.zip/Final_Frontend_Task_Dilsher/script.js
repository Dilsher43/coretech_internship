
// script.js - interactions for Coretech Innovations replica

document.addEventListener('DOMContentLoaded',()=>{

  // Sticky nav background on scroll
  const nav = document.querySelector('.navbar');
  window.addEventListener('scroll', ()=> {
    if(window.scrollY > 40) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
  });

  // Smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach(anchor=>{
    anchor.addEventListener('click', function(e){
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if(target) target.scrollIntoView({behavior:'smooth', block:'start'});
    });
  });

  // Intersection observer for simple reveal animation
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting) e.target.classList.add('reveal');
    });
  }, {threshold:0.12});
  document.querySelectorAll('.card, .team-card, .portfolio-item, .hero').forEach(el=>obs.observe(el));

  // Portfolio modal
  document.querySelectorAll('.portfolio-item').forEach(item=>{
    item.addEventListener('click', ()=>{
      const title = item.dataset.title || 'Project';
      const img = item.innerHTML;
      const modal = document.querySelector('#modal');
      modal.querySelector('.modal-title').textContent = title;
      modal.querySelector('.modal-body').innerHTML = img + '<p style="margin-top:12px">Detailed description for '+title+'.</p>';
      modal.classList.add('open');
    });
  });
  document.querySelectorAll('.modal-close, .modal-backdrop').forEach(el=>{
    el.addEventListener('click', ()=> document.querySelector('#modal').classList.remove('open'));
  });

  // Simple contact form validation
  const form = document.querySelector('#contactForm');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const name = form.querySelector('[name=name]');
      const email = form.querySelector('[name=email]');
      const message = form.querySelector('[name=message]');
      let ok=true;
      if(!name.value.trim()){ ok=false; name.style.borderColor='crimson'}
      if(!/^\S+@\S+\.\S+$/.test(email.value)){ ok=false; email.style.borderColor='crimson'}
      if(!message.value.trim()){ ok=false; message.style.borderColor='crimson'}
      if(ok){ alert('Message sent — (demo). Thank you!'); form.reset(); }
    });
    ['input','change'].forEach(evt=>{
      form.querySelectorAll('input,textarea').forEach(i=>i.addEventListener(evt, ()=> i.style.borderColor='')));
  }

  // Dark/light toggle stored in localStorage
  const toggle = document.querySelector('#themeToggle');
  const root = document.documentElement;
  const saved = localStorage.getItem('ct_theme');
  if(saved==='dark') root.classList.add('dark');
  if(toggle){
    toggle.addEventListener('click', ()=>{
      root.classList.toggle('dark');
      localStorage.setItem('ct_theme', root.classList.contains('dark') ? 'dark' : 'light');
    });
  }

});
