const galleryItems = document.querySelectorAll('.gallery-item img');
const lightbox = document.querySelector('.lightbox');
const lightboxImg = document.querySelector('.lightbox-img');
const closeBtn = document.querySelector('.close');
const nextBtn = document.querySelector('.next');
const prevBtn = document.querySelector('.prev');

let currentIndex = 0;

galleryItems.forEach((img, index) => {
  img.addEventListener('click', () => {
    currentIndex = index;
    showImage();
  });
});

function showImage() {
  lightbox.classList.add('active');
  lightboxImg.src = galleryItems[currentIndex].src;
}

closeBtn.addEventListener('click', () => {
  lightbox.classList.remove('active');
});

nextBtn.addEventListener('click', () => {
  currentIndex = (currentIndex + 1) % galleryItems.length;
  showImage();
});

prevBtn.addEventListener('click', () => {
  currentIndex = (currentIndex - 1 + galleryItems.length) % galleryItems.length;
  showImage();
});

document.addEventListener('keydown', (e) => {
  if (!lightbox.classList.contains('active')) return;
  if (e.key === 'Escape') lightbox.classList.remove('active');
  if (e.key === 'ArrowRight') {
    currentIndex = (currentIndex + 1) % galleryItems.length;
    showImage();
  }
  if (e.key === 'ArrowLeft') {
    currentIndex = (currentIndex - 1 + galleryItems.length) % galleryItems.length;
    showImage();
  }
});
