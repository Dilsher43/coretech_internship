// Toggle Mobile Menu
const hamburger = document.querySelector(".hamburger");
const navLinks = document.querySelector(".nav-links");

hamburger.addEventListener("click", () => {
  navLinks.classList.toggle("active");
  hamburger.classList.toggle("open");
});

// Sticky Navbar
window.addEventListener("scroll", () => {
  document.querySelector(".navbar").classList.toggle("sticky", window.scrollY > 50);
});