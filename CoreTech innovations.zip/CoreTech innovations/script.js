// Preloader
window.addEventListener('load', function () {
    const pre = document.getElementById('preloader');
    if (pre) { pre.style.opacity = 0; setTimeout(() => pre.remove(), 400); }
});

// Smooth scroll + active link
const links = document.querySelectorAll('.nav-link');
function setActiveLink() {
    let pos = window.scrollY + 120;
    document.querySelectorAll('section').forEach(sec => {
        if (sec.offsetTop <= pos && (sec.offsetTop + sec.offsetHeight) > pos) {
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            const a = document.querySelector('.nav-link[href="#' + sec.id + '"]');
            if (a) a.classList.add('active');
        }
    });
}
setActiveLink();
window.addEventListener('scroll', () => {
    setActiveLink();
    const header = document.getElementById('header');
    if (window.scrollY > 30) header.classList.add('scrolled'); else header.classList.remove('scrolled');
});

// Mobile menu
const toggle = document.getElementById('menu-toggle');
toggle.addEventListener('click', () => {
    document.querySelector('.nav-list').classList.toggle('open');
    if (document.querySelector('.nav-list').classList.contains('open')) {
        document.querySelector('.nav-list').style.display = 'flex';
        document.querySelector('.nav-list').style.flexDirection = 'column';
        document.querySelector('.nav-list').style.position = 'absolute';
        document.querySelector('.nav-list').style.top = '64px';
        document.querySelector('.nav-list').style.right = '20px';
        document.querySelector('.nav-list').style.background = '#fff';
        document.querySelector('.nav-list').style.padding = '12px';
        document.querySelector('.nav-list').style.boxShadow = '0 12px 30px rgba(11,18,32,0.06)';
    } else {
        document.querySelector('.nav-list').removeAttribute('style');
    }
});

// Smooth anchor links
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function (e) {
        e.preventDefault();
        const id = this.getAttribute('href').slice(1);
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
});

// Simple form "success" feedback
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', () => {
        alert('Thank you! Your message has been received (demo).');
        contactForm.reset();
    });
}
