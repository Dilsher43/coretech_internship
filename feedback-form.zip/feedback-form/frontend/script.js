document.getElementById("feedbackForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const responseMsg = document.getElementById("responseMsg");

  if (!name || !email || message.length < 10) {
    responseMsg.style.color = "red";
    responseMsg.textContent = "Please fill all fields correctly!";
    return;
  }

  const res = await fetch("../backend/submit_feedback.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, message })
  });

  const data = await res.json();

  if (data.status === "success") {
    responseMsg.style.color = "green";
  } else {
    responseMsg.style.color = "red";
  }

  responseMsg.textContent = data.message;
});